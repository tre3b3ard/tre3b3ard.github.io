# Delios Compendium v2.2.0 — Install Guide

## What this is
A Foundry VTT module containing the complete Delios campaign content as nine compendium packs:
Callings (12 classes), Paths (48 subclasses), Features (397), Species (14), Backgrounds (8),
Grimoire (163 spells), Armory (49 items), Bestiary (24 stat blocks, DM-only visibility),
and the Primer & Rules journal.


## New in v2.2.0
- Saving throw proficiencies and class skill choices now apply on character creation. They were
  stored in fields the current dnd5e schema no longer reads; both are now granted the official
  way, as level-1 Trait advancements restricted to the primary class (multiclass dips do not
  grant saves). Re-drag the calling to fix existing characters.

## New in v2.1.0
- Natural weapons are now real attacks: the Patagonian Beak, Khajit Claws, Fens Bite, Centauri
  Hooves, and the Clan-Beast Beast Claws roll to hit (Strength, proficient) and roll their
  damage with the ability modifier included. Re-drag the species to refresh existing characters.
- Rider features (Battle Dance, Elemental Strike) and dual-effect features (Wings and Claws)
  are deliberately untouched; their text explains the rider and the wings keep their action.

## New in v2.0.0
- Schema-native release: every generated field validated directly against the dnd5e system
  source. Class items use the current hd structure and declare their primary abilities
  (multiclassing prerequisites now work); path spell grants use the native method/prepared
  form of always-prepared; origin feat choices use the native count structure. Nothing depends
  on legacy migration shims for the fields we control.
- If ability score improvements are not appearing at level 4/8/12/16/19: the class item on the
  character predates v1.6. Remove the calling from the sheet and re-drag it from the pack, and
  Foundry replays all advancement up to the current level, including ASI prompts.

## New in v1.9.0
- Full proficiency sweep: every calling now grants its armor and weapon training as level-1
  advancement, every background grants its tool and language line (fixed or as a choice), and
  features whose text says "you gain proficiency with X" now grant it mechanically.
- Features that force a saving throw now roll it: save type, DC (explicit formula where stated,
  spellcasting DC otherwise), and damage with class-level scaling formulas. Healing features
  with an activation roll their healing.
- Broader activation coverage ("use your reaction", "use a bonus action to") and the
  "can't use it again until you finish a rest" single-use pattern now stamp correctly.

## New in v1.8.0
- Lay on Hands is now fully actionable: a bonus action with a pool of 5 x Oathsworn level per
  long rest and a healing roll. Use the consumption amount in the usage dialog to spend points.
- Features across the module whose text declares an activation (action, bonus action, reaction)
  or a use count with rest recovery are now clickable with tracked uses, instead of plain text.
  Channel options remain actions that expend the base feature's shared pool.
- Existing characters: re-drag the calling or path to refresh feature items.

## New in v1.7.0
- New background: Raqassa Dancer, canonized from Amira (Trista). Grants Acrobatics and
  Performance, a musical instrument, and an origin feat choice of Dual Wielder (as played)
  or Musician; the dancer's equipment package is listed on the entry. Reconstructed details
  are labeled on the item.

## New in v1.6.0
- Level-up now offers Ability Score Improvement or Feat at levels 4, 8, 12, and 16 on every
  calling, plus an Epic Boon advancement at 19, using the system's native chooser. Browse or
  drop any feat (Delios origin feats or the system's 2024 feats) in that dialog.
- Backgrounds now grant their Origin Feat as a proper either/or choice during the level-1 flow,
  backed by ten new origin feat reference entries in the features pack.
- Compendium Browser type hints added to the manifest so Delios packs index cleanly and fast.
- Existing characters: re-drag the calling onto the sheet to pick up the ASI prompts (Foundry
  applies missed advancements up to current level), or add a feat directly from the features pack.

## New in v1.5.0
- Path spells now populate automatically. All 48 paths grant their listed spells as always-prepared
  through advancement at the listed levels, and features that say "you learn the X cantrip" now
  actually grant that cantrip, on paths and callings alike. Re-drag a path onto an existing
  character to pick up the grants; new characters get them during the level-3 flow.
- 16 spells added to the Grimoire to complete the grant graph: Delian aliases (Quarry-Brand,
  Become the Wind, Voice of the Courts, Foresee, Frost, Shape-Water, Steppe-Storm) and core
  reference entries (Fly, Bane, Thunderous Smite, and others) marked "use the standard 2024
  rules text." Grimoire now holds 188 spells.
- Fixed a curly-apostrophe lookup bug that broke resolution for Warden's Stillness and
  Hunter's Mark references.

## New in v1.4.0
- The Grit, Defeat Rule automated: any player character healed from 0 HP automatically gains one
  level of exhaustion (capped at 6) with a chat announcement. Ships in the bundled script; works
  with any healing source, including Midi-applied healing.
- Path of the Spellblade and Path of the Quick-Fingered are now proper Intelligence third-casters;
  their subclass items grant spell slot progression natively (found in the v1.4 full audit).
- Full-module QA audit run across all nine packs: structural integrity, every advancement grant
  resolved, class and caster data, bestiary parsing, and compiled-database round-trips. See the
  QA report shipped alongside this release.

## New in v1.3.0
- Lore of Delios: a bundled config script relabels the Religion skill to Lore of Delios across every
  sheet, roll dialog, and skill picker. No setup needed beyond having the module enabled.
- Path selection during level-up: every calling now carries a Subclass advancement at level 3, so
  Foundry prompts for a Path when a calling reaches 3rd level. Dragging a path from the Delios Paths
  pack onto the sheet also still works at any time from level 3.
- Reminder: the Delios exhaustion rule (-2 per level to d20 tests, death at 6) is the 2024 core rule
  and is already enforced natively by the system. No configuration needed.

## New in v1.2.0 (Ube canonization)
- Saga Sayer background added (custom, DM-approved, from Taylor's Ube). Skills History + Performance
  are derived by elimination against class, species, and feat grants on the sheet; the ability-score
  triad (Cha/Int/Wis) and the alternate feat (Musician) are reconstructed and marked as such on the item.
- Mind-Touch added to the Grimoire as the canonical Delian cantrip for mind sliver, cross-referenced to
  Gift of the Voice (Patron: the Voice in the Cold), which grants it.
- Eight familiar-core spells added so Ube's full list exists in the Grimoire: Hex, Hellish Rebuke,
  Unseen Servant, Suggestion, Mind Whip, Shocking Grasp, Sorcerous Burst, Spare the Dying.
- Climbing Spear added to the Armory (the Patagonian pike; identical stats, Push mastery).
- Note: The Voice in the Cold required no changes. It is a canonical gated path and Ube's Gift of the
  Voice matches it exactly. Data note for a future pass: the canonical path spell table reuses the
  name "Mind-Touch" for dissonant whispers and mind whip at 3rd level; consider renaming those rows.

## New in v1.1.0
- Delios Bestiary: all 24 stat blocks from the Monster Manual as ready-to-use NPC actors with
  parsed abilities, AC, HP, speeds, senses, resistances, skills, attacks (with damage rolls),
  save-based abilities (with DCs), recharge powers, and legendary actions. Foldered by book
  section, Hunger through The Named. Player visibility is off by default.
- Oath of the Elements replaces Oath of Glory (design decision 2026-07-11). Full canonical
  features at 3rd, 7th, 15th, and 20th, plus tenets and the Elements Path Spells table. The
  Oathsworn class page lists the updated four paths.
- Shard of the Courts is now a canonical Grimoire entry (level 1 evocation, the Delian name
  for chromatic orb) with attack, damage, and slot scaling wired for automation.

## Install on The Forge
1. Bazaar, then My Foundry, then the Import Wizard. Upload delios-compendium-v1.1.0.zip as a module.
2. If v1.0.0 is installed, this replaces it (same module id).
3. Enable the module in your world under Manage Modules.

## Install on local Foundry
Extract so the delios-compendium folder sits in Data/modules, restart, enable.

## After enabling
- Drag background, species, calling, then path onto a blank actor; advancement handles the rest.
- Bestiary actors drag straight to any scene. CR, XP, and proficiency are set; attack items roll
  to hit and damage through your Midi stack immediately.
- Content is authored against the dnd5e 3.x data model and migrates forward automatically on use.

## Remaining known gaps
- The Avatar of the Sundering Hunger uses narrative HP per its stat block ("momentary, treat as
  525 per form"); the actor is set to 525 with the full note preserved in its block text.
- Elementalism and a few Elements path spells reference 2024 core spells not in the Delios
  grimoire data; they appear in the path's spell table but are not separate spell items.
- App parity: the character builder app still contains Oath of Glory. Update the app's embedded
  JSON to match this design decision.
