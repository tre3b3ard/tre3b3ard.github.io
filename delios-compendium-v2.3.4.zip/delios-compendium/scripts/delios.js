/**
 * Delios: The Long Winter of Kings — system configuration and Grit automation
 * v1.4.0
 */

/* Lore of Delios replaces Religion (same skill slot, Intelligence-based). */
Hooks.once("init", () => {
  try {
    if (game.system.id !== "dnd5e") return;
    const rel = CONFIG.DND5E?.skills?.rel;
    if (rel) rel.label = "Lore of Delios";
    console.log("Delios | Config applied: Lore of Delios skill label");
  } catch (e) {
    console.error("Delios | init config error", e);
  }
});

/* The Grit — Defeat Rule: a character revived from 0 HP gains one level of exhaustion. */
Hooks.on("preUpdateActor", (actor, changed, options, userId) => {
  try {
    if (actor.type !== "character") return;
    const newHP = foundry.utils.getProperty(changed, "system.attributes.hp.value");
    if (newHP === undefined || newHP === null) return;
    const oldHP = foundry.utils.getProperty(actor, "system.attributes.hp.value");
    if (oldHP === 0 && newHP > 0) options.deliosDefeatRule = true;
  } catch (e) {
    console.error("Delios | Defeat Rule preUpdate error", e);
  }
});

Hooks.on("updateActor", async (actor, changed, options, userId) => {
  try {
    if (!options.deliosDefeatRule) return;
    if (game.user.id !== userId) return; /* only the client that made the change applies it */
    const cur = foundry.utils.getProperty(actor, "system.attributes.exhaustion") ?? 0;
    const next = Math.min(6, cur + 1);
    if (next === cur) return;
    await actor.update({ "system.attributes.exhaustion": next });
    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<strong>The Grit \u00b7 Defeat Rule:</strong> ${actor.name} returns from 0 HP and gains a level of exhaustion (now ${next}${next >= 6 ? " \u2014 death" : ""}).`
    });
  } catch (e) {
    console.error("Delios | Defeat Rule update error", e);
  }
});
